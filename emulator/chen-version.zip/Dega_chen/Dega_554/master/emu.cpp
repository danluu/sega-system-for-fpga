// Emu module
#include "app.h"

char EmuRomName[256]="";
char EmuStateName[256]="";

char *EmuTitle=NULL;

static unsigned char *MasterRom=NULL;
static int MasterRomLen=0;

static FILE *FileExport=NULL; // File currently being exported

static int GameGearRom()
{
  int Len=0;
  Len=strlen(EmuRomName); if (Len<3) return 0;
  if (memicmp(".gg",EmuRomName+Len-3,3)==0) return 1;
  return 0;
}

int EmuInit()
{
  int Ret=0;
  Ret=MastInit(); if (Ret!=0) { AppError("MastInit Failed",0); return 1; }

  EmuTitle=NULL;
  return 0;
}

int EmuExit()
{
  MastExit();
  return 0;
}

// Change all upper case titles to lower case
static int NoUpper(char *Title)
{
  int i=0,Len=0;
  // Change to lower case
  if (Title==NULL) return 1;
  Len=strlen(EmuTitle);
  
  for (i=0;i<Len;i++)
  {
    int c=EmuTitle[i];
    if (c>='a' && c<='z') return 0;
  }
  // No lower case letters

  for (i=0;i<Len;i++) { EmuTitle[i]=(char)tolower(EmuTitle[i]); }
  return 0;
}

int EmuLoad()
{
  int Ret=0;
  if (EmuRomName[0]==0) return 1;

  EmuFree(); // make sure nothing is loaded

  // Load the rom
  Ret=MastLoadRom(EmuRomName,&MasterRom,&MasterRomLen);
  if (Ret!=0)
  {
    char Temp[128];
    sprintf(Temp,"Could not load %.100s",EmuRomName);
    AppError(Temp,0);
    return 1;
  }

  if (EmuTitle!=NULL) free(EmuTitle);
  EmuTitle=GetStubName(EmuRomName);
  NoUpper(EmuTitle);

  Ret=GameGearRom(); // Detect Game Gear from the filename
  MastEx&=~MX_GG; if (Ret) MastEx|=MX_GG;

  MastSetRom(MasterRom,MasterRomLen); // Plug in the rom
  return 0;
}

// Free the loaded rom
int EmuFree()
{
  MastSetRom(NULL,0); // Unplug the rom
  MastEx&=~MX_GG;

  if (EmuTitle!=NULL) free(EmuTitle);  EmuTitle=NULL;

  if (MasterRom!=NULL) free(MasterRom);  MasterRom=NULL; MasterRomLen=0;
  return 0;
}

int EmuFrame()
{
  if (MasterRom==NULL) return 1;
  return MastFrame();
}
