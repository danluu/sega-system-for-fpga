
    /////////////////////////////////////////
    // start of 4 byte z80 instruction decode
    /////////////////////////////////////////      
	bus_pre.n4 = inst4;
	bus_pre.nn2 = inst4;
	bus_pre.nn2 = (unsigned short)(((bus_pre.nn2) << 8) + inst3);
	bus_pre.b4 = (unsigned char)((inst4 & 0x38) >> 3);

	switch(inst1)
	{
//---------------------------------------------------
//					DD group
//---------------------------------------------------
	case 0xDD:
		switch(inst2)			//I_word[23:16])
		{
		case 0x36:		// checked tchen **********************
			INSTR_RUN(LD_IX_d_n); goto end_inst;
		case 0x21:		// checked tchen **********************
			INSTR_RUN(LD_IX_nn2); goto end_inst;
		case 0x2A:		// checked tchen **********************
			INSTR_RUN(LD_IX_nn); goto end_inst;
		case 0x22:		// checked tchen **********************
			INSTR_RUN(LD_nn_IX); goto end_inst;
		case 0xCB:
			switch(inst4)		//I_word[7:0])
			{
			case 0x06:		// checked tchen **********************
				INSTR_RUN(RLC_IX_d); goto end_inst;
			case 0x16:		// checked tchen **********************
				INSTR_RUN(RL_m_3); goto end_inst;
			case 0x0E:		// checked tchen **********************
				INSTR_RUN(RRC_m_3); goto end_inst;
			case 0x1E:		// checked tchen **********************
				INSTR_RUN(RR_m_3); goto end_inst;
			case 0x26:		// checked tchen **********************
				INSTR_RUN(SLA_m_3); goto end_inst;
			case 0x2E:		// checked tchen **********************
				INSTR_RUN(SRA_m_3); goto end_inst;
			case 0x3E:		// checked tchen **********************
				INSTR_RUN(SRL_m_3); goto end_inst;
			default: 
				switch (inst4 & 0xC7)
				{
				// 01???110:
				case 0x46:		// checked tchen **********************
					INSTR_RUN(BIT_b_IX_d); goto end_inst;
				// 11???110:
				case 0xC6:		// checked tchen **********************
					INSTR_RUN(SET_b_IX_d); goto end_inst;
				// 10???110:
				case 0x86:		// checked tchen **********************
					INSTR_RUN(RES_b_m_3); goto end_inst;
				}
			}

		default: break;
		}
		break;
			  
//---------------------------------------------------
//					ED group
//---------------------------------------------------
	case 0xED:
		switch(inst2 & 0xCF)
		{
		// 01??1011:
		case 0x4B:		// checked tchen **********************
			INSTR_RUN(LD_dd_nn); goto end_inst;
		// 01??0011:
		case 0x43:		// checked tchen **********************
			INSTR_RUN(LD_nn_dd); goto end_inst;
		default: break;
		}
		
		break;

//---------------------------------------------------
//					FD group
//---------------------------------------------------
	case 0xFD:
		switch(inst2)			//I_word[23:16])
		{
		case 0x36:		// checked tchen **********************
			INSTR_RUN(LD_IY_d_n); goto end_inst;
		case 0x21:		// checked tchen **********************
			INSTR_RUN(LD_IY_nn2); goto end_inst;
		case 0x2A:		// checked tchen **********************
			INSTR_RUN(LD_IY_nn); goto end_inst;
		case 0x22:		// checked tchen **********************
			INSTR_RUN(LD_nn_IY); goto end_inst;
		case 0xCB:
			switch(inst4)		//I_word[7:0])
			{
			case 0x06:		// checked tchen **********************
				INSTR_RUN(RLC_IY_d); goto end_inst;
			case 0x16:		// checked tchen **********************
				INSTR_RUN(RL_m_4); goto end_inst;
			case 0x0E:		// checked tchen **********************
				INSTR_RUN(RRC_m_4); goto end_inst;
			case 0x1E:		// checked tchen **********************
				INSTR_RUN(RR_m_4); goto end_inst;
			case 0x26:		// checked tchen **********************
				INSTR_RUN(SLA_m_4); goto end_inst;
			case 0x2E:		// checked tchen **********************
				INSTR_RUN(SRA_m_4); goto end_inst;
			case 0x3E:		// checked tchen **********************
				INSTR_RUN(SRL_m_4); goto end_inst;
			default: 
				switch(inst4 & 0xC7)
				{
				// 01???110:
				case 0x46:		// checked tchen **********************
					INSTR_RUN(BIT_b_IY_d); goto end_inst;
				// 11???110:
				case 0xC6:		// checked tchen **********************
					INSTR_RUN(SET_b_IY_d); goto end_inst;
				// 10???110:
				case 0x86:		// checked tchen **********************
					INSTR_RUN(RES_b_m_4); goto end_inst;
				}
			}
			default: break;
		}
		break;

		default: break;
	}

