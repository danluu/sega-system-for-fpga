
    /////////////////////////////////////////
    // start of 3 byte z80 instruction decode
    /////////////////////////////////////////      
	bus_pre.n3 = inst3;
	bus_pre.d = inst3;
	bus_pre.nn1 = inst3;
	bus_pre.nn1 = (unsigned short)((bus_pre.nn1 << 8) + inst2);

	switch(inst1)							//I_word[31:24])
	{
	case 0x3A:		// checked tchen **********************
		INSTR_RUN(LD_A_nn); goto end_inst;
	case 0x32:		// checked tchen **********************
		INSTR_RUN(LD_nn_A); goto end_inst;
	case 0x2A:		// checked tchen **********************
		INSTR_RUN(LD_HL_nn); goto end_inst;
	case 0x22:		// checked tchen **********************
		INSTR_RUN(LD_nn_HL); goto end_inst;
	case 0xC3:		// checked tchen **********************
		INSTR_RUN(JP_nn); goto end_inst;
	case 0xCD:		// checked tchen **********************
		INSTR_RUN(CALL_nn); goto end_inst;

//---------------------------------------------------
//					DD group
//---------------------------------------------------
	case 0xDD:
		switch(inst2)					//I_word[23:16])
		{
		case 0x86:		// checked tchen **********************
			INSTR_RUN(ADD_A_IX_d); goto end_inst;
		case 0x8E:		// checked tchen **********************
			INSTR_RUN(ADC_A_s_4); goto end_inst;
		case 0x96:		// checked tchen **********************
			INSTR_RUN(SUB_s_4); goto end_inst;
		case 0x9E:		// checked tchen **********************
			INSTR_RUN(SBC_A_s_4); goto end_inst;
		case 0xA6:		// checked tchen **********************
			INSTR_RUN(AND_s_4); goto end_inst;
		case 0xB6:		// checked tchen **********************
			INSTR_RUN(OR_s_4); goto end_inst;
		case 0xAE:		// checked tchen **********************
			INSTR_RUN(XOR_s_4); goto end_inst;
		case 0xBE:		// checked tchen **********************
			INSTR_RUN(CP_s_4); goto end_inst;
		case 0x34:		// checked tchen **********************
			INSTR_RUN(INC_IX_d); goto end_inst;
		case 0x35:		// checked tchen **********************
			INSTR_RUN(DEC_m_3); goto end_inst;
		default:
			if ((inst2 & 0xC0) == 0x40)			// 8'b01??????:
			{
				// if((I_word[21:19] != 3'b110) && (I_word[18:16] == 3'b110))
				if (((inst2 & 0x38) != 0x30) && ((inst2 & 0x07) == 0x06))		// checked tchen **********************
				{  INSTR_RUN(LD_r_IX_d); goto end_inst;  }
				// else if((I_word[21:19] == 3'b110) && (I_word[18:16] != 3'b110))
				else if (((inst2 & 0x38) == 0x30) && ((inst2 & 0x07) != 0x06))		// checked tchen **********************
				{  INSTR_RUN(LD_IX_d_r); goto end_inst;  }
			}
		}
		break;

//---------------------------------------------------
//					FD group
//---------------------------------------------------
		case 0xFD:
              switch(inst2)					//I_word[23:16])
			  {
			  case 0x86:		// checked tchen **********************
                  INSTR_RUN(ADD_A_IY_d); goto end_inst;
			  case 0x8E:		// checked tchen **********************
                  INSTR_RUN(ADC_A_s_5); goto end_inst;
			  case 0x96:		// checked tchen **********************
                  INSTR_RUN(SUB_s_5); goto end_inst;
			  case 0x9E:		// checked tchen **********************
                  INSTR_RUN(SBC_A_s_5); goto end_inst;
			  case 0xA6:		// checked tchen **********************
                  INSTR_RUN(AND_s_5); goto end_inst;
			  case 0xB6:		// checked tchen **********************
                  INSTR_RUN(OR_s_5); goto end_inst;
			  case 0xAE:		// checked tchen **********************
                  INSTR_RUN(XOR_s_5); goto end_inst;
			  case 0xBE:		// checked tchen **********************
                  INSTR_RUN(CP_s_5); goto end_inst;
			  case 0x34:		// checked tchen **********************
                  INSTR_RUN(INC_IY_d); goto end_inst;
			  case 0x35:		// checked tchen **********************
                  INSTR_RUN(DEC_m_4); goto end_inst;
			  default:
				  if ((inst2 & 0xC0) == 0x40)			// 8'b01??????:
				  {
					  // if((I_word[21:19] != 3'b110) && (I_word[18:16] == 3'b110))
					  if (((inst2 & 0x38) != 0x30) && ((inst2 & 0x07) == 0x06))		// checked tchen **********************
					  {  INSTR_RUN(LD_r_IY_d); goto end_inst;  }
					  // else if((I_word[21:19] == 3'b110) && (I_word[18:16] != 3'b110))
					  else if (((inst2 & 0x38) == 0x30) && ((inst2 & 0x07) != 0x06))		// checked tchen **********************
					  {  INSTR_RUN(LD_IY_d_r); goto end_inst;  }
				  }
			  }
			  break;

		default:
			// 00??0001:
			if ((inst1 & 0xCF) == 0x01)		// checked tchen **********************
			{  INSTR_RUN(LD_dd_nn2); goto end_inst;  }
			// 11???010:
			else if ((inst1 & 0xC7) == 0xC2)		// checked tchen **********************
			{  INSTR_RUN(JP_cc_nn); goto end_inst;  }
			// 11???100:
			else if ((inst1 & 0xC7) == 0xC4)		// checked tchen **********************
			{  INSTR_RUN(CALL_cc_nn); goto end_inst;  }
	} 