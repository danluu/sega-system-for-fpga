

#ifndef __DOZE_554_H
#define __DOZE_554_H

#include "..\\mast\\doze.h"

void DozeRun_chi();



#endif

