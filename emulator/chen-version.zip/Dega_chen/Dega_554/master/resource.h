//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by app.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       102
#define IDR_ACCELERATOR1                103
#define ID_FILE_LOADROM                 40001
#define ID_FILE_RESET                   40002
#define ID_FILE_FREEROM                 40003
#define ID_FILE_EXIT                    40004
#define ID_SETUP_PAL                    40011
#define ID_SETUP_JAPAN                  40012
#define ID_SETUP_FMCHIP                 40013
#define ID_SETUP_OVERLAY_NONE           40014
#define ID_SETUP_OVERLAY_YUV            40015
#define ID_SETUP_OVERLAY_RGB            40016
#define ID_SOUND_ENHANCEPSG             40022
#define ID_INPUT_KEYBOARD               40031
#define ID_INPUT_JOYSTICK               40032
#define ID_STATE_IMPORT                 40041
#define ID_STATE_EXPORT                 40042
#define ID_STATE_AUTOLOADSAVE           40043
#define ID_SOUND_QUALITY_OFF            40057
#define ID_SOUND_QUALITY_12000HZ        40058
#define ID_SOUND_QUALITY_44100HZ        40059
#define ID_SETUP_FULLSCREEN             40060
#define ID_SOUND_VGMLOG_START           40063
#define ID_SOUND_VGMLOG_STOP            40064
#define ID_SETUP_REDBLUE3D              40065
#define ID_SOUND_VGMLOG_SAMPLEACCURATE  40067
#define ID_SETUP_PAUSE                  40068
#define ID_SETUP_ONEFRAME               40069
#define ID_OPTIONS_SCREENSHOT           40070
#define ID_STATE_LOADSTATE              40071
#define ID_STATE_SAVESTATE              40072

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40073
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
