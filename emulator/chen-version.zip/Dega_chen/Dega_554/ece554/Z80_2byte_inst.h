
	/////////////////////////////////////////
    // start of 2 byte z80 instruction decode
    /////////////////////////////////////////
	bus_pre.n2 = inst2;
	bus_pre.r3 = (unsigned char)((inst2 & 0x38) >> 3);
	bus_pre.r4 = (unsigned char)(inst2 & 0x07);
	bus_pre.dd2 = (unsigned char)((inst2 & 0x30) >> 4);
	bus_pre.pp2 = (unsigned char)((inst2 & 0x30) >> 4);
	bus_pre.rr2 = (unsigned char)((inst2 & 0x30) >> 4);
	
	switch(inst1)					//I_word[31:24]
	{
	case 0xC6:		// checked tchen **********************
		INSTR_RUN(ADD_A_n); goto end_inst;
	case 0xCE:		// checked tchen **********************
		INSTR_RUN(ADC_A_s_2); goto end_inst;
	case 0xD6:		// checked tchen **********************
		INSTR_RUN(SUB_s_2); goto end_inst;
	case 0xDE:		// checked tchen **********************
		INSTR_RUN(SBC_A_s_2); goto end_inst;
	case 0xE6:		// checked tchen **********************
		INSTR_RUN(AND_s_2); goto end_inst;
	case 0xF6:		// checked tchen **********************
		INSTR_RUN(OR_s_2); goto end_inst;
	case 0xEE:		// checked tchen **********************
		INSTR_RUN(XOR_s_2); goto end_inst;
	case 0xFE:		// checked tchen **********************
		INSTR_RUN(CP_s_2); goto end_inst;
	case 0x18:		// checked tchen **********************
		INSTR_RUN(JR_e); goto end_inst;
	case 0x38:		// checked tchen **********************
		INSTR_RUN(JR_C_e); goto end_inst;
	case 0x30:		// checked tchen **********************
		INSTR_RUN(JR_NC_e); goto end_inst;
	case 0x28:		// checked tchen **********************
		INSTR_RUN(JR_Z_e); goto end_inst;
	case 0x20:		// checked tchen **********************
		INSTR_RUN(JR_NZ_e); goto end_inst;
	case 0x10:		// checked tchen **********************
		INSTR_RUN(DJNZ_e); goto end_inst;
	case 0xDB:		// checked tchen **********************
		INSTR_RUN(IN_A_n); goto end_inst;
	case 0xD3:		// checked tchen **********************
		INSTR_RUN(OUT_n_A); goto end_inst;
		
//---------------------------------------------------
//					CB group
//---------------------------------------------------
	case 0xCB:
		switch(inst2 & 0xF8)
		{
		case 0x00:			// 00000???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(RLC_r); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(RLC_HL); goto end_inst;  }
		case 0x10:			// 00010???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(RL_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(RL_m_2); goto end_inst;  }
		case 0x08:			// 00001???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(RRC_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(RRC_m_2); goto end_inst;  }
		case 0x18:			// 00011???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(RR_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(RR_m_2); goto end_inst;  }
		case 0x20:			// 00100???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(SLA_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(SLA_m_2); goto end_inst;  }
		case 0x28:			// 00101???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(SRA_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(SRA_m_2); goto end_inst;  }
		case 0x38:			// 00111???:
			//(I_word[18:16] != 3'b110)
			if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(SRL_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(SRL_m_2); goto end_inst;  }
		default:
			switch(inst2 & 0xC0)
			{
			case 0x40:			// 01??????:
				//(I_word[18:16] != 3'b110)
				if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
				{  INSTR_RUN(BIT_b_r); goto end_inst;  }
				else		// checked tchen **********************
				{  INSTR_RUN(BIT_b_HL); goto end_inst;  }
			case 0xC0:			// 11??????:
				//(I_word[18:16] != 3'b110)
				if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
				{  INSTR_RUN(SET_b_r); goto end_inst;  }
				else		// checked tchen **********************
				{  INSTR_RUN(SET_b_HL); goto end_inst;  }
			case 0x80:			// 10??????:
				//(I_word[18:16] != 3'b110)
				if ((inst2 & 0x07) != 0x06)		// checked tchen **********************
				{  INSTR_RUN(RES_b_m_1); goto end_inst;  }
				else		// checked tchen **********************
				{  INSTR_RUN(RES_b_m_2); goto end_inst;  }
			}
		}  
		break;
              
//---------------------------------------------------
//					DD group
//---------------------------------------------------
		case 0xDD:
			switch(inst2)					//I_word[23:16])
			{
			case 0xF9:		// checked tchen **********************
				INSTR_RUN(LD_SP_IX); goto end_inst;
			case 0xE5:		// checked tchen **********************
				INSTR_RUN(PUSH_IX); goto end_inst;
			case 0xE1:		// checked tchen **********************
				INSTR_RUN(POP_IX); goto end_inst;
			case 0xE3:		// checked tchen **********************
				INSTR_RUN(EX_SP_IX); goto end_inst;
			case 0x23:		// checked tchen **********************
				INSTR_RUN(INC_IX); goto end_inst;
			case 0x2B:		// checked tchen **********************
				INSTR_RUN(DEC_IX); goto end_inst;
			case 0xE9:		// checked tchen **********************
				INSTR_RUN(JP_IX); goto end_inst;
			default:
				// 00??1001:
				if ((inst2 & 0xCF) == 0x09)		// checked tchen **********************
				{  INSTR_RUN(ADD_IX_pp); goto end_inst;  }
			}
			break;

//---------------------------------------------------
//					ED group
//---------------------------------------------------
          case 0xED:
              switch(inst2)					//I_word[23:16])
			  {
			  case 0x57:		// checked tchen **********************
                  INSTR_RUN(LD_A_I); goto end_inst;
			  case 0x5F:		// checked tchen **********************
                  INSTR_RUN(LD_A_R); goto end_inst;
			  case 0x47:		// checked tchen **********************
                  INSTR_RUN(LD_I_A); goto end_inst;
			  case 0x4F:		// checked tchen **********************
                  INSTR_RUN(LD_R_A); goto end_inst;
			  case 0xA0:		// checked tchen **********************
                  INSTR_RUN(LDI); goto end_inst;
			  case 0xB0:		// checked tchen **********************
                  INSTR_RUN(LDIR); goto end_inst;
			  case 0xA8:		// checked tchen **********************
                  INSTR_RUN(LDD); goto end_inst;
			  case 0xB8:		// checked tchen **********************
                  INSTR_RUN(LDDR); goto end_inst;
			  case 0xA1:		// checked tchen **********************
                  INSTR_RUN(CPI); goto end_inst;
			  case 0xB1:		// checked tchen **********************
                  INSTR_RUN(CPIR); goto end_inst;
			  case 0xA9:		// checked tchen **********************
                  INSTR_RUN(CPD); goto end_inst;
			  case 0xB9:		// checked tchen **********************
                  INSTR_RUN(CPDR); goto end_inst;
			  case 0x44:		// checked tchen **********************
				  INSTR_RUN(NEG); goto end_inst;
			  case 0x46:		// checked tchen **********************
				  INSTR_RUN(IM0); goto end_inst;
			  case 0x56:		// checked tchen **********************
				  INSTR_RUN(IM1); goto end_inst;
			  case 0x5E:		// checked tchen **********************
				  INSTR_RUN(IM2); goto end_inst;
			  case 0x6F:		// checked tchen **********************
				  INSTR_RUN(RLD); goto end_inst;
			  case 0x67:		// checked tchen **********************
				  INSTR_RUN(RRD); goto end_inst;
			  case 0x4D:
				  INSTR_RUN(RETI); goto end_inst;
			  case 0x45:
				  INSTR_RUN(RETN); goto end_inst;
			  case 0xA2:		// checked tchen **********************
				  INSTR_RUN(INI); goto end_inst;
			  case 0xB2:		// checked tchen **********************
				  INSTR_RUN(INIR); goto end_inst; 
         	  case 0xAA:		// checked tchen **********************
				  INSTR_RUN(IND); goto end_inst;
			  case 0xBA:		// checked tchen **********************
				  INSTR_RUN(INDR); goto end_inst;
			  case 0xA3:
				  INSTR_RUN(OUTI); goto end_inst;
			  case 0xB3:
				  INSTR_RUN(OTIR); goto end_inst;
			  case 0xAB:
				  INSTR_RUN(OUTD); goto end_inst;
			  case 0xBB:
				  INSTR_RUN(OTDR); goto end_inst;
			  default:
				  // 01??1010:
				  if ((inst2 & 0xCF) == 0x4A)		// checked tchen **********************
				  {  INSTR_RUN(ADC_HL_ss); goto end_inst;  }
				  // 01??0010:
				  else if ((inst2 & 0xCF) == 0x42)		// checked tchen **********************
				  {  INSTR_RUN(SBC_HL_ss); goto end_inst;  }
				  // 01???000:
				  else if ((inst2 & 0xC7) == 0x40)		// checked tchen **********************
				  {  INSTR_RUN(IN_r_C); goto end_inst;  }
				  // 01???001:
				  else if ((inst2 & 0xC7) == 0x41)		// checked tchen **********************
				  {  INSTR_RUN(OUT_C_r); goto end_inst;  }
			  }
			  break;	// this is the break Tsung-chi forgot to put
  
//---------------------------------------------------
//					FD group
//---------------------------------------------------
	      case 0xFD:
			  switch(inst2)					//I_word[23:16])
			  {
			  case 0xF9:		// checked tchen **********************
				  INSTR_RUN(LD_SP_IY); goto end_inst;
			  case 0xE5:		// checked tchen **********************
				  INSTR_RUN(PUSH_IY); goto end_inst;
			  case 0xE1:		// checked tchen **********************
				  INSTR_RUN(POP_IY); goto end_inst;
			  case 0xE3:		// checked tchen **********************
				  INSTR_RUN(EX_SP_IY); goto end_inst;
			  case 0x23:		// checked tchen **********************
				  INSTR_RUN(INC_IY); goto end_inst;
			  case 0x2B:		// checked tchen **********************
				  INSTR_RUN(DEC_IY); goto end_inst;
			  case 0xE9:		// checked tchen **********************
				  INSTR_RUN(JP_IY); goto end_inst;
			  default:
				  // 00??1001:
				  if ((inst2 & 0xCF) == 0x09)		// checked tchen **********************
				  {  INSTR_RUN(ADD_IY_rr); goto end_inst;  } 
			  }
			  break;  // this is the break Tsung-chi forgot to put

		  default:
			  if( (inst1 & 0xC7) == 0x06)				// 00???110:
			  {
				  // (I_word[29:27] != 3'b110)
				  if( (inst1 & 0x38) != 0x30)		// checked tchen **********************
				  {  INSTR_RUN(LD_r_n); goto end_inst;  }
				  else		// checked tchen **********************
				  {  INSTR_RUN(LD_HL_n); goto end_inst;  }
			  }
	}
