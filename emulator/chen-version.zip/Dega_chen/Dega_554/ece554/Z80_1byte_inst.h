
    /////////////////////////////////////////
    // start of 1 byte z80 instruction decode
    /////////////////////////////////////////
	bus_pre.r1 = (unsigned char)((inst1 & 0x38) >> 3);
	bus_pre.r2 = (unsigned char)(inst1 & 0x07);
	bus_pre.dd1 = (unsigned char)((inst1 & 0x30) >> 4);
	bus_pre.qq1 = (unsigned char)((inst1 & 0x30) >> 4);

	switch(inst1)						//I_word[31:24])
	{
	case 0x00:		// checked tchen **********************
		INSTR_RUN(NOP); goto end_inst;
	case 0x0A:		// checked tchen **********************
		INSTR_RUN(LD_A_BC); goto end_inst;
	case 0x1A:		// checked tchen **********************
		INSTR_RUN(LD_A_DE); goto end_inst;
	case 0x02:		// checked tchen **********************
		INSTR_RUN(LD_BC_A); goto end_inst;
	case 0x12:		// checked tchen **********************
		INSTR_RUN(LD_DE_A); goto end_inst;
	case 0xF9:		// checked tchen **********************
		INSTR_RUN(LD_SP_HL); goto end_inst;
	case 0xEB:		// checked tchen **********************
		INSTR_RUN(EX_DE_HL); goto end_inst;
	case 0x08:		// checked tchen **********************
		INSTR_RUN(EX_AF_AF); goto end_inst;
	case 0xD9:		// checked tchen **********************
		INSTR_RUN(EXX); goto end_inst;
	case 0xE3:		// checked tchen **********************
		INSTR_RUN(EX_SP_HL); goto end_inst;
	case 0x27:		// checked tchen **********************
		INSTR_RUN(DAA); goto end_inst;
	case 0x2F:		// checked tchen **********************
		INSTR_RUN(CPL); goto end_inst;
	case 0x3F:		// checked tchen **********************
		INSTR_RUN(CCF); goto end_inst;
	case 0x37:		// checked tchen **********************
		INSTR_RUN(SCF); goto end_inst;
	case 0xF3:		// checked tchen **********************
		INSTR_RUN(DI); goto end_inst;
	case 0xFB:		// checked tchen **********************
		INSTR_RUN(EI); goto end_inst;
	case 0x07:		// checked tchen **********************
		INSTR_RUN(RLCA); goto end_inst;
	case 0x17:		// checked tchen **********************
		INSTR_RUN(RLA); goto end_inst;
	case 0x0F:		// checked tchen **********************
		INSTR_RUN(RRCA); goto end_inst;
	case 0x1F:		// checked tchen **********************
		INSTR_RUN(RRA); goto end_inst;
	case 0xE9:		// checked tchen **********************
		INSTR_RUN(JP_HL); goto end_inst;
	case 0xC9:		// checked tchen **********************
		INSTR_RUN(RET); goto end_inst;

	default:
//----------------------------------------------------------
//			 Group only concerned [5:4] 2 bit				 
//----------------------------------------------------------
		switch( inst1 & 0xCF )
		{
		// 11??0101:
		case 0xC5:		// checked tchen **********************
			INSTR_RUN(PUSH_qq); goto end_inst;
		// 11??0001:
        case 0xC1:		// checked tchen **********************
            INSTR_RUN(POP_qq); goto end_inst;
		// 00??1001:
		case 0x09:		// checked tchen **********************
            INSTR_RUN(ADD_HL_ss); goto end_inst;
		// 00??0011:
		case 0x03:		// checked tchen **********************
            INSTR_RUN(INC_ss); goto end_inst;
		// 00??1011:		
		case 0x0B:		// checked tchen **********************
            INSTR_RUN(DEC_ss); goto end_inst;
		}
//----------------------------------------------------------
//			 Group only concerned [2:0] 3 bit				 
//----------------------------------------------------------
		switch(inst1 & 0xF8)
		{
		case 0x80:			// 10000???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(ADD_A_r); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(ADD_A_HL); goto end_inst;  }
		case 0x88:			// 10001???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(ADC_A_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(ADC_A_s_3); goto end_inst;  }
		case 0x90:			// 10010???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(SUB_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(SUB_s_3); goto end_inst;  }
		case 0x98:			// 10011???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(SBC_A_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(SBC_A_s_3); goto end_inst;  }
		case 0xA0:			// 10100???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(AND_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(AND_s_3); goto end_inst;  }
		case 0xB0:			// 10110???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(OR_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(OR_s_3); goto end_inst;  }
		case 0xA8:			// 10101???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(XOR_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(XOR_s_3); goto end_inst;  }
		case 0xB8:			// 10111???
			//I_word[26:24] != 3'b110
			if ((inst1 & 0x07) != 0x06)		// checked tchen **********************
			{  INSTR_RUN(CP_s_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(CP_s_3); goto end_inst;  }
		}

//----------------------------------------------------------
//			 Group only concerned [5:3] 3 bit				 
//----------------------------------------------------------
        switch(inst1 & 0xC7)
		{
		case 0x04:		// 00???100
			//I_word[29:27] != 3'b110
			if ((inst1 & 0x38) != 0x30)		// checked tchen **********************
			{  INSTR_RUN(INC_r); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(INC_HL); goto end_inst;  }
		case 0x05:		// 00???101
			//I_word[29:27] != 3'b110
			if ((inst1 & 0x38) != 0x30)		// checked tchen **********************
			{  INSTR_RUN(DEC_m_1); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(DEC_m_2); goto end_inst;  }
		// 11???000
		case 0xC0:		// checked tchen **********************
			{  INSTR_RUN(RET_cc); goto end_inst;  }
		// 11???111
		case 0xC7:		// checked tchen **********************
            {  INSTR_RUN(RST_p); goto end_inst;  }
		}
//-----------------------------------------------------------
        if ( (inst1 & 0xC0) == 0x40 )			// 01??????:
		{
			// if((I_word[29:27] != 3'b110) && (I_word[26:24] != 3'b110))
			if (((inst1 & 0x38) != 0x30) && ((inst1 & 0x07) != 0x06))		// checked tchen **********************
			{  INSTR_RUN(LD_r_r); goto end_inst;  }
			// else if((I_word[29:27] != 3'b110) && (I_word[26:24] == 3'b110))
			else if (((inst1 & 0x38) != 0x30) && ((inst1 & 0x07) == 0x06))		// checked tchen **********************
			{  INSTR_RUN(LD_r_HL); goto end_inst;  }
			// else if((I_word[29:27] == 3'b110) && (I_word[26:24] != 3'b110))
			else if (((inst1 & 0x38) == 0x30) && ((inst1 & 0x07) != 0x06))		// checked tchen **********************
			{  INSTR_RUN(LD_HL_r); goto end_inst;  }
			else		// checked tchen **********************
			{  INSTR_RUN(HALT); goto end_inst;  }
		}
	}
