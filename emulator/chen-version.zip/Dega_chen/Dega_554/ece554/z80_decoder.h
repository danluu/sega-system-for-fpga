

#ifndef __Z80_DECODER_H
#define __Z80_DECODER_H

#define ORIG_Z80


void DozeAsmRun_chi();


#endif

