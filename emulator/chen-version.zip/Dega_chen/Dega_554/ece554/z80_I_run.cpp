/*==========================================================================================*
|	Z80 Instructions Execution																|
|																							|
|						Writen by					Tsung-Chi, Lin		(I/O group)			|
| ----------------------------------------------------------------------------------------- |
|	Date:																					|
|	11/01/2002	Original version established.												|
|	11/03/2002	Complete Load Group Instruction												|
|	11/04/2002	Complete Exchange, Block Transfer, Search Group Instruction					|
|	11/04/2002	Complete Arithmetic Group Instruction 										|
|	11/05/2002	Complete ROTATE and SHIFT Group Instruction									|
|	11/05/2002	Complete BIT, RESET, and TEST Group Instruction								|
|	11/05/2002	Complete JUMP Group Instruction												|
|	11/05/2002	Complete CALL and RETURN Group Instruction									|
|	11/06/2002	Complete INPUT and OUTPUT Group Instruction									|
|	11/10/2002	Fix the document error of Instruction 'ADD_IX_pp'							| 
|	11/12/2002	Fix the Problem with not updating Flag Instruction							|
|	11/14/2002	Fix the P/V and Z flag in BC-- Instruction									|
|   11/18/2002  Fix (IX+d) (IY+d) to sign extended
*==========================================================================================*/

#include "..\\mast\\doze.h"
#include "dozeint_554.h"
#include "DataValue.h"
#include "z80_I_ID.h"
#include "z80_I_run.h"

inline void inc_r(void)
{
	if ((Doze.ir & 0x00fe) == 0x00fe)
		Doze.ir &= 0xff01;
	else
		Doze.ir+=2;
}

inline void change_flag(void)
{
	Doze.af = (unsigned short)( ( Doze.af & 0xff00 ) + ( ((unsigned short)flag.S<<7) + ((unsigned short)flag.Z<<6)
		+ ((unsigned short)flag.no_use2<<5) + ((unsigned short)flag.H<<4)
		+ ((unsigned short)flag.no_use1<<3) + ((unsigned short)flag.PV<<2)
		+ ((unsigned short)flag.N<<1) + ((unsigned short)flag.C) ) );
}

inline void run_DAA(void)
{
	unsigned char temp = (unsigned char)((Doze.af >> 8) & 0x00ff);
	unsigned char high = (unsigned char)((temp >> 4) & 0x000f);
	unsigned char low = (unsigned char)(temp & 0x000f);

	switch ( (flag.N<<2) + (flag.C<<1) + (flag.H) )
	{
	case 0x0:
		if ( high>=0x0 && high<=0x8 && low>=0xA && low<=0xF ) 
		{  temp += 0x06;  flag.C = 0;  flag.H = 1;  }
		else if ( high>=0xA && high<=0xF && low>=0x0 && low<=0x9 ) 
		{  temp += 0x60;  flag.C = 1;  flag.H = 0;  }
		else if ( high>=0x9 && high<=0xF && low>=0xA && low<=0xF ) 
		{  temp += 0x66;  flag.C = 1;  flag.H = 1;  }
		break;
	case 0x1:
		if ( high>=0x0 && high<=0x9 && low>=0x0 && low<=0x3 ) 
		{  temp += 0x06;  flag.C = 0;  flag.H  = 1;  }
		else if ( high>=0xA && high<=0xF && low>=0x0 && low<=0x3 ) 
		{  temp += 0x66;  flag.C = 1;  flag.H  = 1;  }
		break;
	case 0x2:
		if ( high>=0x0 && high<=0x2 && low>=0x0 && low<=0x9 ) 
		{  temp += 0x60;  flag.C = 1;  flag.H  = 0;  }
		else if ( high>=0x0 && high<=0x2 && low>=0xA && low<=0xF ) 
		{  temp += 0x66;  flag.C = 1;  flag.H  = 1;  }
		break;
	case 0x3:
		if ( high>=0x0 && high<=0x3 && low>=0x0 && low<=0x3 ) 
		{  temp += 0x66;  flag.C = 1;  flag.H  = 1;  }
		break;
	case 0x4:
		break;
	case 0x5:
		if ( high>=0x0 && high<=0x8 && low>=0x6 && low<=0xF ) 
		{  temp += 0xFA;  flag.C = 0;  flag.H  = 1;  }  // H?
		break;
	case 0x6:
		if ( high>=0x7 && high<=0xF && low>=0x0 && low<=0x9 ) 
		{  temp += 0xA0;  flag.C = 1;  flag.H  = 0;  }  // H?
		break;
	case 0x7:
		if ( high>=0x6 && high<=0x7 && low>=0x6 && low<=0xf ) 
		{  temp += 0x9A;  flag.C = 1;  flag.H  = 1;  }  // H?
		break;
	default:
		printf("Error in run_DAA();\n");
		break;
	}
	flag.S = ( (temp & 0x0080) == 0x80 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0x00 ) ? 1 : 0;
	flag.PV = parity_check(temp);
	Doze.af = (unsigned short)( ((int)temp<<8) + (Doze.af&0x00ff) );
}

unsigned char getRegVal(unsigned char r)	//return the value of specified Register
{
	switch (r)
	{
	case 0x07:	// Reg A
		return (unsigned char)(Doze.af >> 8);
		break;
	case 0x00:	// Reg B
		return (unsigned char)(Doze.bc >> 8);
		break;
	case 0x01:	// Reg C
		return (unsigned char)(Doze.bc & 0x00ff);
		break;
	case 0x02:	// Reg D
		return (unsigned char)(Doze.de >> 8);
		break;
	case 0x03:	// Reg E
		return (unsigned char)(Doze.de & 0x00ff);
		break;
	case 0x04:	// Reg H
		return (unsigned char)(Doze.hl >> 8);
		break;
	case 0x05:	// Reg L
		return (unsigned char)(Doze.hl & 0x00ff);
		break;
	default:
		printf("Error in getRegVal(unsigned char r);\n");
		return 0x00;
	}
}

void setRegVal (unsigned char r, unsigned char v) //store the value to specified Register
{
	switch (r)
	{
	case 0x07:	// Reg A
		Doze.af = (unsigned short)( ((int)v << 8) + (Doze.af & 0x00ff) );
		break;
	case 0x00:	// Reg B
		Doze.bc = (unsigned short)( ((int)v << 8) + (Doze.bc & 0x00ff) );
		break;
	case 0x01:	// Reg C
		Doze.bc = (unsigned short)( v + (Doze.bc & 0xff00) );
		break;
	case 0x02:	// Reg D
		Doze.de = (unsigned short)( ((int)v << 8) + (Doze.de & 0x00ff) );
		break;
	case 0x03:	// Reg E
		Doze.de = (unsigned short)( v + (Doze.de & 0xff00) );
		break;
	case 0x04:	// Reg H
		Doze.hl = (unsigned short)( ((int)v << 8) + (Doze.hl & 0x00ff) );
		break;
	case 0x05:	// Reg L
		Doze.hl = (unsigned short)( v + (Doze.hl & 0xff00) );
		break;
	default:	//Not specified
		printf("Error in setRegVal(unsigned char r, unsigned char v);\n");
		break;
	}
}

unsigned short getRegPairVal_dd(unsigned char dd) //return the value to specified Register
{
	switch (dd)
	{
		case 0x00:	// RegPair BC
			return Doze.bc;
			break;
		case 0x01:	// RegPair DE
			return Doze.de;
			break;
		case 0x02:	// RegPair HL
			return Doze.hl;
			break;
		case 0x03:	// RegPair SP
			return Doze.sp;
			break;
		default:
			printf("Error in getRegPairVal_dd(unsigned char dd);\n");
			return 0x0000;
	}
}

void setRegPairVal_dd(unsigned char dd, unsigned short v) //store the value to specified Register
{
	switch (dd)
	{
		case 0x00:	// RegPair BC
			Doze.bc = v;
			break;
		case 0x01:	// RegPair DE
			Doze.de = v;
			break;
		case 0x02:	// RegPair HL
			Doze.hl = v;
			break;
		case 0x03:	// RegPair SP
			Doze.sp = v;
			break;
		default:
			printf("Error in setRegPairVal_dd(unsigned char dd, unsigned short v);\n");
			break;
	}
}

unsigned short getRegPairVal_qq(unsigned char qq) //return the value to specified Register
{
	switch (qq)
	{
		case 0x00:	// RegPair BC
			return Doze.bc;
			break;
		case 0x01:	// RegPair DE
			return Doze.de;
			break;
		case 0x02:	// RegPair HL
			return Doze.hl;
			break;
		case 0x03:	// RegPair AF
			return Doze.af;
			break;
		default:
			printf("Error in getRegPairVal_qq(unsigned char qq);\n");
			return 0x0000;
	}
}

void setRegPairVal_qq(unsigned char qq, unsigned short v) //store the value to specified Register
{
	switch (qq)
	{
		case 0x00:	// RegPair BC
			Doze.bc = v;
			break;
		case 0x01:	// RegPair DE
			Doze.de = v;
			break;
		case 0x02:	// RegPair HL
			Doze.hl = v;
			break;
		case 0x03:	// RegPair AF
			Doze.af = v;
			break;
		default:
			printf("Error in setRegPairVal_qq(unsigned char qq, unsigned short v);\n");
			break;
	}
}

unsigned short getRegPairVal_pp(unsigned char pp) //return the value to specified Register
{
	switch (pp)
	{
		case 0x00:	// RegPair BC
			return Doze.bc;
			break;
		case 0x01:	// RegPair DE
			return Doze.de;
			break;
		case 0x02:	// RegPair IX
			return Doze.ix;
			break;
		case 0x03:	// RegPair SP
			return Doze.sp;
			break;
		default:
			printf("Error in getRegPairVal_pp(unsigned char pp);\n");
			return 0;
			break;
	}
}

void setRegPairVal_pp(unsigned char pp, unsigned short v) //store the value to specified Register
{
	switch (pp)
	{
		case 0x00:	// RegPair BC
			Doze.bc = v;
			break;
		case 0x01:	// RegPair DE
			Doze.de = v;
			break;
		case 0x02:	// RegPair IX
			Doze.ix = v;
			break;
		case 0x03:	// RegPair SP
			Doze.sp = v;
			break;
		default:
			printf("Error in setRegPairVal_pp(unsigned char pp, unsigned short v);\n");
			break;
	}
}

unsigned short getRegPairVal_rr (unsigned char rr) //return the value to specified Register
{
	switch (rr)
	{
		case 0x00:	// RegPair BC
			return Doze.bc;
			break;
		case 0x01:	// RegPair DE
			return Doze.de;
			break;
		case 0x02:	// RegPair IY
			return Doze.iy;
			break;
		case 0x03:	// RegPair SP
			return Doze.sp;
			break;
		default: return 0x0000;
	}
}

void setRegPairVal_rr (unsigned char rr, unsigned short v) //store the value to specified Register
{
	switch (rr)
	{
		case 0x00:	// RegPair BC
			Doze.bc = v;
			break;
		case 0x01:	// RegPair DE
			Doze.de = v;
			break;
		case 0x02:	// RegPair IY
			Doze.iy = v;
			break;
		case 0x03:	// RegPair SP
			Doze.sp = v;
			break;
	}
}

unsigned char Arith_add8(unsigned char opd1, unsigned char opd2, bool carry)
{
	int temp = opd1 + opd2 + carry;
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = ( (((opd1&0x000f)+(opd2&0x000f)+carry) & 0x0010) != 0) ? 1 : 0;
	flag.C = ( (temp&0x0100) != 0 ) ? 1 : 0;
	flag.N = 0;
	flag.PV = overflow_check( ((opd1&0x0080)!=0)?1:0, ((opd2&0x0080)!=0)?1:0, flag.S );
	return (unsigned char)(temp&0x00ff);
}

unsigned char Arith_sub8(unsigned char opd1, unsigned char opd2, bool carry)
{
	int temp = opd1 - opd2 - carry;	
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = ( (opd1&0x000f) < ((opd2&0x000f)+carry) ) ? 1 : 0;
	flag.C = ( (opd1&0x00ff) < ((opd2&0x00ff)+carry) ) ? 1 : 0;
	flag.N = 1;
	flag.PV = overflow_check( ((opd1&0x0080)!=0)?1:0, ((opd2&0x0080)!=0)?1:0, flag.S );
	return (unsigned char)(temp&0x00ff);
}

void compare(unsigned char opd1, unsigned char opd2)
{
	int temp = opd1 - opd2;
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = ( (opd1&0x000f) < (opd2&0x000f) ) ? 1 : 0;
	flag.N = 1;
}

unsigned short Arith_add16(unsigned short opd1, unsigned short opd2, bool carry)
{
	int temp = opd1 + opd2 + carry;
	flag.S = ( (temp & 0x8000) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0xffff) == 0 ) ? 1 : 0;
	flag.H = ( (((opd1&0x0fff)+(opd2&0x0fff)+carry) & 0x1000) != 0) ? 1 : 0;
	flag.C = ( (temp&0x10000) != 0 ) ? 1 : 0;
	flag.N = 0;
	flag.PV = overflow_check( ((opd1&0x8000)!=0)?1:0, ((opd2&0x8000)!=0)?1:0, flag.S );
	return (unsigned short)(temp&0xffff);
}

unsigned short Arith_sub16(unsigned short opd1, unsigned short opd2, bool carry)
{
	int temp = opd1 - opd2 - carry;
	flag.S = ( (temp & 0x8000) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0xffff) == 0 ) ? 1 : 0;
	flag.H = ( (opd1&0x0fff) < ((opd2&0x0fff)+carry) ) ? 1 : 0;
	flag.C = ( (opd1&0xffff) < ((opd2&0xffff)+carry) ) ? 1 : 0;
	flag.N = 1;
	flag.PV = overflow_check( ((opd1&0x8000)!=0)?1:0, ((opd2&0x8000)!=0)?1:0, flag.S );
	return (unsigned short)(temp&0xffff);
}

unsigned char Arith_and(unsigned char opd1, unsigned char opd2)
{
	unsigned char temp = (unsigned char)(opd1 & opd2);
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = 1;
	flag.C = 0;
	flag.N = 0;
	flag.PV = parity_check(temp);
	return (unsigned char)(temp&0x00ff);
}

unsigned char Arith_or(unsigned char opd1, unsigned char opd2)
{
	unsigned char temp = (unsigned char)(opd1 | opd2);
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = 0;
	flag.C = 0;
	flag.N = 0;
	flag.PV = parity_check(temp);
	return (unsigned char)(temp&0x00ff);
}

unsigned char Arith_xor(unsigned char opd1, unsigned char opd2)
{
	unsigned char temp = (unsigned char)(opd1 ^ opd2);
	flag.S = ( (temp & 0x0080) != 0 ) ? 1 : 0;
	flag.Z = ( (temp & 0x00ff) == 0 ) ? 1 : 0;
	flag.H = 0;
	flag.C = 0;
	flag.N = 0;
	flag.PV = parity_check(temp);
	return (unsigned char)(temp&0x00ff);
}

bool parity_check(unsigned char opd)
{
	if ((((opd & 0x0080) >> 7)^
		((opd & 0x0040) >> 6)^
		((opd & 0x0020) >> 5)^
		((opd & 0x0010) >> 4)^
		((opd & 0x0008) >> 3)^
		((opd & 0x0004) >> 2)^
		((opd & 0x0002) >> 1)^
		(opd & 0x0001))==0x0000) return 1;
	else return 0;
}

void getSpecBit(unsigned char opd, unsigned char bit_num)	// use for BIT Group
{
	switch(bit_num)
	{
	case 0:
		flag.Z = ((opd&0x01) == 0) ? 1 : 0;
		break;
	case 1:
		flag.Z = ((opd&0x02) == 0) ? 1 : 0;
		break;
	case 2:
		flag.Z = ((opd&0x04) == 0) ? 1 : 0;
		break;
	case 3:
		flag.Z = ((opd&0x08) == 0) ? 1 : 0;
		break;
	case 4:
		flag.Z = ((opd&0x10) == 0) ? 1 : 0;
		break;
	case 5:
		flag.Z = ((opd&0x20) == 0) ? 1 : 0;
		break;
	case 6:
		flag.Z = ((opd&0x40) == 0) ? 1 : 0;
		break;
	case 7:
		flag.Z = ((opd&0x80) == 0) ? 1 : 0;
		break;
	default:
		printf("Error in getSpecBit(unsigned char opd, unsigned char bit_num);\n");
		break;
	}
}

unsigned char setSpecBit(unsigned char opd, unsigned char bit_num)	// use for SET Group
{
	switch(bit_num)
	{
	case 0:
		return (unsigned char)((opd | 0x01) & 0x00ff);
	case 1:
		return (unsigned char)((opd | 0x02) & 0x00ff);
	case 2:
		return (unsigned char)((opd | 0x04) & 0x00ff);
	case 3:
		return (unsigned char)((opd | 0x08) & 0x00ff);
	case 4:
		return (unsigned char)((opd | 0x10) & 0x00ff);
	case 5:
		return (unsigned char)((opd | 0x20) & 0x00ff);
	case 6:
		return (unsigned char)((opd | 0x40) & 0x00ff);
	case 7:
		return (unsigned char)((opd | 0x80) & 0x00ff);
	default:
		printf("Error in setSpecBit(unsigned char opd, unsigned char bit_num);\n");
		return NULL;
	}
}

unsigned char resSpecBit(unsigned char opd, unsigned char bit_num)	// use for SET Group
{
	switch(bit_num)
	{
	case 0:
		return (unsigned char)((opd & 0xfe) & 0x00ff);
	case 1:
		return (unsigned char)((opd & 0xfd) & 0x00ff);
	case 2:
		return (unsigned char)((opd & 0xfb) & 0x00ff);
	case 3:
		return (unsigned char)((opd & 0xf7) & 0x00ff);
	case 4:
		return (unsigned char)((opd & 0xef) & 0x00ff);
	case 5:
		return (unsigned char)((opd & 0xdf) & 0x00ff);
	case 6:
		return (unsigned char)((opd & 0xbf) & 0x00ff);
	case 7:
		return (unsigned char)((opd & 0x7f) & 0x00ff);
	default:
		printf("Error in resSpecBit(unsigned char opd, unsigned char bit_num);\n");
		return NULL;
	}
}

unsigned short sign_extend(unsigned char a)
{
	return (unsigned short)(( a >> 7 ) ? ( 0xff00 + a ) : a);
}

/*
int sign_extend(unsigned short a)
{
	return (( a >> 15 ) ? ( 0xffff0000 + a ) : a);
}
*/

bool overflow_check(bool sign1, bool sign2, bool sign_result)
{
	// (+) - (-) == (-)
	if ( sign1==0 && sign2==1 && sign_result==1 && flag.N==1 ) return 1;
	// (-) - (+) == (+)
	else if ( sign1==1 && sign2==0 && sign_result==0 && flag.N==1 ) return 1;
	// (+) + (+) == (-)
	else if ( sign1==0 && sign2==0 && sign_result==1 && flag.N==0 ) return 1;
	// (-) + (-) == (+)
	else if ( sign1==1 && sign2==1 && sign_result==0 && flag.N==0 ) return 1;
	// no overflow
	else return 0;
}

bool condition_check(unsigned char cond)
{
  switch (cond)
  {
	  case 0x00:
		  if (!flag.Z) return true;
		  else return false;
	  case 0x01:
		  if (flag.Z) return true;
		  else return false;
	  case 0x02:
		  if (!flag.C) return true;
		  else return false;
	  case 0x03:
		  if (flag.C) return true;
		  else return false;
	  case 0x04:
		  if (!flag.PV) return true;
		  else return false;
	  case 0x05:
		  if (flag.PV) return true;
		  else return false;
	  case 0x06:
		  if (!flag.S) return true;
		  else return false;
	  case 0x07:
		  if (flag.S) return true;
		  else return false;
	  default: 
		  printf("Error in condition_check(unsigned char cond);\n");
		  return false;
  }
}



void INSTR_RUN(unsigned char z80_ID)
{
	unsigned short tempreg;
	unsigned char tempreg2;

	static unsigned int inst_count = 0;

	flag.C = (Doze.af & 0x01);			// Carry flag
	flag.N = (Doze.af & 0x02) >> 1;		// Add/Subtract flag
	flag.PV = (Doze.af & 0x04) >> 2;
	flag.no_use1 = (Doze.af & 0x08) >> 3;
	flag.H = (Doze.af & 0x10) >> 4;			// Half_carry flag
	flag.no_use2 = 	(Doze.af & 0x20) >> 5;
	flag.Z = (Doze.af & 0x40) >> 6;			// Zero flag
	flag.S = (Doze.af & 0x80) >> 7;			// Sign flag

	switch(z80_ID)
	{
	case  NOP:		// checked tchen **********************
		inc_r();
		nDozeCycles-= 4;
		break;
	case  ADC_A_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2), flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;		
	case  ADC_A_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			bus_pre.n2, flag.C) << 8) + (Doze.af & 0x00ff));
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case  ADC_A_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead(Doze.hl), flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 7;
		break;
	case  ADC_A_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 
			flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  ADC_A_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 
			flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  ADC_HL_ss:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.hl = Arith_add16( Doze.hl, getRegPairVal_dd(bus_pre.dd2), flag.C );
		change_flag();
		nDozeCycles-= 15;
		break;
	case  ADD_A_HL:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead(Doze.hl), 0) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 7;
		break;
	case  ADD_A_IX_d:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 0) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;		
	case  ADD_A_IY_d:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 0) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  ADD_A_n:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			bus_pre.n2, 0) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case  ADD_A_r:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_add8((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2), 0) << 8 ) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;
	case  ADD_HL_ss:		// checked tchen **********************
		inc_r();
		Doze.hl = Arith_add16( Doze.hl, getRegPairVal_dd(bus_pre.dd1), 0 );
		change_flag();
		nDozeCycles-= 11;
		break;		
	case  ADD_IX_pp:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = (unsigned char)( (flag.S<<2) + (flag.Z<<1) + (flag.PV) );
		Doze.ix = Arith_add16( Doze.ix, getRegPairVal_pp(bus_pre.pp2), 0 );
		flag.S = ( (tempreg2&0x04) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg2&0x02) != 0 ) ? 1 : 0;
		flag.PV = ( (tempreg2&0x01) != 0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 15;
		break;
	case  ADD_IY_rr:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = (unsigned char)( (flag.S<<2) + (flag.Z<<1) + (flag.PV) );
		Doze.iy = Arith_add16( Doze.iy, getRegPairVal_rr(bus_pre.rr2), 0 );
		flag.S = ( (tempreg2&0x04) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg2&0x02) != 0 ) ? 1 : 0;
		flag.PV = ( (tempreg2&0x01) != 0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 15;
		break;
	case  AND_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_and((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;		
	case  AND_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_and((unsigned char)(Doze.af>>8), 
			bus_pre.n2) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case  AND_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_and((unsigned char)(Doze.af>>8), 
			DozeRead(Doze.hl)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 7;
		break;
	case  AND_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_and((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  AND_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_and((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  BIT_b_HL:		// checked tchen **********************
		inc_r();  inc_r();
		getSpecBit( DozeRead(Doze.hl), bus_pre.r3 );
		flag.H = 1;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 12;
		break;
	case  BIT_b_IX_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		getSpecBit( DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), bus_pre.b4 );
		flag.H = 1;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 24; // 20 in Z80 document
		break;
	case  BIT_b_IY_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		getSpecBit( DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), bus_pre.b4 );
		flag.H = 1;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 24; // 20 in Z80 document
		break;
	case  BIT_b_r:		// checked tchen **********************
		inc_r();  inc_r();
		getSpecBit( getRegVal(bus_pre.r4), bus_pre.r3 );
		flag.H = 1;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 8;
		break;
	case  CALL_cc_nn:		// checked tchen **********************
		inc_r();
		if ( condition_check(bus_pre.r1) )
		{
			DozeWrite( --Doze.sp, (unsigned char)(Doze.pc >> 8));
			DozeWrite( --Doze.sp, (unsigned char)(Doze.pc & 0x00ff) );
			Doze.pc = bus_pre.nn1;
			nDozeCycles-= 17;
		}
		else nDozeCycles-= 10;
		break;
	case  CALL_nn:		// checked tchen **********************
		inc_r();
		DozeWrite( --Doze.sp, (unsigned char)(Doze.pc >> 8) );
		DozeWrite( --Doze.sp, (unsigned char)(Doze.pc & 0x00ff) );
		Doze.pc = bus_pre.nn1;
		nDozeCycles-= 17;
		break;
	case  CCF:		// checked tchen **********************
		inc_r();
		flag.C = !flag.C;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case CP_s_1:		// checked tchen **********************
		inc_r();
		Arith_sub8((unsigned char)(Doze.af>>8), getRegVal(bus_pre.r2), 0);
		change_flag();
		nDozeCycles-= 4;
		break;
	case CP_s_2:		// checked tchen **********************
		inc_r();
		Arith_sub8((unsigned char)(Doze.af>>8), (unsigned char)bus_pre.n2, 0);
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case CP_s_3:		// checked tchen **********************
		inc_r();
		Arith_sub8((unsigned char)(Doze.af>>8), DozeRead(Doze.hl), 0);
		change_flag();
		nDozeCycles-= 7;
		break;
	case CP_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 0);
		change_flag();
		nDozeCycles-= 19;
		break;
	case CP_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 0);
		change_flag();
		nDozeCycles-= 19;
		break;	
	case  CPD:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl--);
		Doze.bc--;		
		compare( (unsigned char)(Doze.af>>8), tempreg2 );
		flag.PV = (Doze.bc != 0x0000) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  CPDR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl--);
		Doze.bc--;
		compare( (unsigned char)(Doze.af>>8), tempreg2 );
		if ( Doze.bc == 0 ) 
		{
			flag.PV = 0;
			nDozeCycles-= 16;
		}
		else
		{
			flag.PV = 1;
			nDozeCycles-= 21;
			Doze.pc-= 2;
			inc_r();
		}
		change_flag();
		break;
	case  CPI:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl++);
		Doze.bc--;		
		compare( (unsigned char)(Doze.af>>8), tempreg2 );
		flag.PV = (Doze.bc != 0x0000) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  CPIR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl++);
		Doze.bc--;
		compare( (unsigned char)(Doze.af>>8), tempreg2 );
		if ( Doze.bc == 0 ) 
		{
			flag.PV = 0;
			nDozeCycles-= 16;
		}
		else
		{
			flag.PV = 1;
			nDozeCycles-= 21;
			Doze.pc-= 2;
			inc_r();
		}
		change_flag();
		break;
	case  CPL:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)(Doze.af ^ 0xff00);
		flag.H = 1;
		flag.N = 1;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  DAA:		// checked tchen **********************
		inc_r();
		run_DAA();
		change_flag();
		nDozeCycles-= 4;
		break;
	case  DEC_IX:	// checked tchen **********************
		inc_r();  inc_r();
		Doze.ix--;
		nDozeCycles-= 10;
		break;
	case  DEC_IY:	// checked tchen **********************
		inc_r();  inc_r();
		Doze.iy--;
		nDozeCycles-= 10;
		break;
	case  DEC_m_1:		// checked tchen **********************
		inc_r();
		tempreg2 = flag.C;	// keep carry
		setRegVal( bus_pre.r1, Arith_sub8(getRegVal(bus_pre.r1), 1, 0) );
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  DEC_m_2:		// checked tchen **********************
		inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( Doze.hl, Arith_sub8(DozeRead(Doze.hl), 1, 0) );	
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 11;
		break;
	case  DEC_m_3:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)),
			Arith_sub8(DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 1, 0) );	
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 23;
		break;
	case  DEC_m_4:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)),
			Arith_sub8(DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 1, 0) );	
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 23;
		break;
	case  DEC_ss:		// checked tchen **********************
		inc_r();
		setRegPairVal_dd( bus_pre.dd1, (unsigned short)(getRegPairVal_dd(bus_pre.dd1) - 1) );
		nDozeCycles-= 6;
		break;
	case  DI:		// checked tchen **********************
		inc_r();
		Doze.iff = 0x0000;
		nDozeCycles-= 4;
		break;
	case  DJNZ_e:		// checked tchen **********************
		inc_r();
		tempreg2 = (unsigned char)((Doze.bc >> 8) - 1);
		Doze.bc = (unsigned short)(((int)tempreg2 << 8) + (Doze.bc & 0x00ff));
		if (tempreg2 != 0)
		{
			Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2) );
			nDozeCycles-= 13;
		}
		else
			nDozeCycles-= 8;
		break;
	case  EI:		// checked tchen **********************
		inc_r();
		if ( nDozeEi!=1 && Doze.iff!=0x0101 ) nDozeEi = 2;
		Doze.iff = 0x0101;	
		nDozeCycles-= 4;	
		break;
	case  EX_SP_HL:		// checked tchen **********************
		inc_r();
		tempreg = (unsigned short)( ((int)DozeRead((unsigned short)(Doze.sp+1)) << 8)
			+ DozeRead(Doze.sp) );
		DozeWrite( Doze.sp, (unsigned char)(Doze.hl & 0x00ff) );
		DozeWrite( (unsigned short)(Doze.sp+1), (unsigned char)(Doze.hl >> 8) );
		Doze.hl = tempreg;
		nDozeCycles-= 19;
		break;
	case  EX_SP_IX:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = (unsigned short)( ((int)DozeRead((unsigned short)(Doze.sp+1)) << 8)
			+ DozeRead(Doze.sp) );
		DozeWrite( Doze.sp, (unsigned char)(Doze.ix & 0x00ff) );
		DozeWrite( (unsigned short)(Doze.sp+1), (unsigned char)(Doze.ix >> 8) );		
		Doze.ix = tempreg;
		nDozeCycles-= 23;
		break;
	case  EX_SP_IY:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = (unsigned short)( ((int)DozeRead((unsigned short)(Doze.sp+1)) << 8)
			+ DozeRead(Doze.sp) );
		DozeWrite( Doze.sp, (unsigned char)(Doze.iy & 0x00ff) );
		DozeWrite( (unsigned short)(Doze.sp+1), (unsigned char)(Doze.iy >> 8) );
		Doze.iy = tempreg;
		nDozeCycles-= 23;
		break;
	case  EX_AF_AF:		// checked tchen **********************
		inc_r();
		tempreg = Doze.af;
		Doze.af = Doze.af2;
		Doze.af2 = tempreg;
		nDozeCycles-= 4;
		break;
	case  EX_DE_HL:		// checked tchen **********************
		inc_r();
		tempreg = Doze.de;
		Doze.de = Doze.hl;
		Doze.hl = tempreg;
		nDozeCycles-= 4;
		break;
	case  EXX:		// checked tchen **********************
		inc_r();
		tempreg = Doze.bc;
		Doze.bc = Doze.bc2;
		Doze.bc2 = tempreg;
		tempreg = Doze.de;
		Doze.de = Doze.de2;
		Doze.de2 = tempreg;
		tempreg = Doze.hl;
		Doze.hl = Doze.hl2;
		Doze.hl2 = tempreg;
		nDozeCycles-= 4;
		break;		
	case  HALT:		// checked tchen **********************
		inc_r();
		Doze.pc--;
		tempreg = (unsigned short)(nDozeCycles >> 2);
		Doze.ir= (unsigned short)( ((Doze.ir+(tempreg<<1))&0x00fe) | (Doze.ir&0xff01) ); // Increase R register
		nDozeCycles &= 0x3;
		nDozeCycles-= 4;
		break;
	case  IM0:		// checked tchen **********************
		inc_r();
		Doze.im = 0;
		nDozeCycles-= 8;
		break;
	case  IM1:		// checked tchen **********************
		inc_r();
		Doze.im = 1;
		nDozeCycles-= 8;
		break;
	case  IM2:		// checked tchen **********************
		inc_r();
		Doze.im = 2;
		nDozeCycles-= 8;
		break;
	case  IN_A_n:		// checked tchen **********************
		inc_r();
		tempreg2 = DozeIn( (unsigned short)((Doze.af & 0xff00) + bus_pre.n2) );
		Doze.af = (unsigned short)(((int)tempreg2 << 8) + (Doze.af & 0x00ff));
		nDozeCycles-= 11;
		break;
	case  IN_r_C:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeIn( Doze.bc );
		setRegVal( bus_pre.r3, tempreg2 );
		flag.S = ( (tempreg2 & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg2 & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check(tempreg2);
		change_flag();
		nDozeCycles-= 12;
		break;
	case  INC_HL:		// checked tchen **********************
		inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( Doze.hl, Arith_add8(DozeRead(Doze.hl), 1, 0) );
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 11;
		break;
	case  INC_IX_d:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)), 
			Arith_add8(DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 1, 0) );
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 23;
		break;
	case  INC_IY_d:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = flag.C;	// keep carry
		DozeWrite( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)), 
			Arith_add8(DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 1, 0) );
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 23;
		break;
	case  INC_IX:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ix++;
		nDozeCycles-= 10;
		break;
	case  INC_IY:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.iy++;
		nDozeCycles-= 10;
		break;
	case  INC_r:		// checked tchen **********************
		inc_r();
		tempreg2 = flag.C;	// keep carry
		setRegVal( bus_pre.r1, Arith_add8(getRegVal(bus_pre.r1), 1, 0) );
		flag.C = tempreg2;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  INC_ss:		// checked tchen **********************
		inc_r();
		setRegPairVal_dd( bus_pre.dd1, (unsigned short)(getRegPairVal_dd(bus_pre.dd1) + 1) );
		nDozeCycles-= 6;
		break;
	case  IND:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeIn(Doze.bc);
		DozeWrite(Doze.hl, tempreg2);
		Doze.hl--;
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  INDR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeIn(Doze.bc);
		DozeWrite(Doze.hl, tempreg2);
		Doze.hl--;
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		if ( !flag.Z )		// B != 0, repeat
		{
			inc_r();
			Doze.pc -= 2;
			nDozeCycles-= 21;
		}
		else				// B == 0, stop
		{
			flag.PV = 1;
			change_flag();
			nDozeCycles-= 16;
		}
		break;
	case  INI:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeIn(Doze.bc);
		DozeWrite(Doze.hl, tempreg2);
		Doze.hl++;
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  INIR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeIn(Doze.bc);
		DozeWrite(Doze.hl, tempreg2);
		Doze.hl++;
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		if ( !flag.Z )		// B != 0, repeat
		{
			inc_r();
			Doze.pc -= 2;
			nDozeCycles-= 21;
		}
		else				// B == 0, stop
		{
			flag.PV = 1;
			change_flag();
			nDozeCycles-= 16;
		}
		break;
	case  JP_HL:		// checked tchen **********************
		inc_r();
		Doze.pc = Doze.hl;
		nDozeCycles-= 4;
		break;
	case  JP_IX:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.pc = Doze.ix;
		nDozeCycles-= 8;
		break;
	case  JP_IY:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.pc = Doze.iy;
		nDozeCycles-= 8;
		break;
	case  JP_cc_nn:		// checked tchen **********************
		inc_r();
		if ( condition_check(bus_pre.r1) ) Doze.pc = bus_pre.nn1;
		nDozeCycles-= 10;
		break;
	case  JP_nn:		// checked tchen **********************
		inc_r();
		Doze.pc = bus_pre.nn1;
		nDozeCycles-= 10;
		break;
	case  JR_NC_e:		// checked tchen **********************
		inc_r();
		if ( !flag.C )
		{
			Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2));
			nDozeCycles-= 12;
		}
		else nDozeCycles-= 7;
		break;
	case  JR_C_e:		// checked tchen **********************
		inc_r();
		if ( flag.C )
		{
			Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2));
			nDozeCycles-= 12;
		}
		else nDozeCycles-= 7;
		break;
	case  JR_e:		// checked tchen **********************
		inc_r();
		Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2));
		nDozeCycles-= 12;
		break;
	case  JR_NZ_e:		// checked tchen **********************
		inc_r();
		if (!flag.Z)
		{
			Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2));
			nDozeCycles-= 12;
		}
		else nDozeCycles-= 7;
		break;
	case  JR_Z_e:		// checked tchen **********************
		inc_r();
		if (flag.Z)
		{
			Doze.pc = (unsigned short)(Doze.pc + sign_extend(bus_pre.n2));
			nDozeCycles-= 12;
		}
		else nDozeCycles-= 7;
		break;
	case  LD_BC_A:		// checked tchen **********************
		inc_r();
		DozeWrite( Doze.bc, (unsigned char)(Doze.af >> 8) );
		nDozeCycles-= 7;
		break;
	case  LD_DE_A:		// checked tchen **********************
		inc_r();
		DozeWrite( Doze.de, (unsigned char)(Doze.af >> 8) );
		nDozeCycles-= 7;
		break;
	case  LD_HL_n:		// checked tchen **********************
		inc_r();
		DozeWrite( Doze.hl, bus_pre.n2 );
		nDozeCycles-= 10;
		break;		
	case  LD_HL_r:		// checked tchen **********************
		inc_r();
		DozeWrite( Doze.hl, getRegVal(bus_pre.r2) );
		nDozeCycles-= 7;
		break;
	case  LD_IX_d_n:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)), bus_pre.n4 );
		nDozeCycles-= 19;
		break;	
	case  LD_IX_d_r:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)), getRegVal(bus_pre.r4) );
		nDozeCycles-= 19;
		break;		
	case  LD_IY_d_n:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)), bus_pre.n4 );
		nDozeCycles-= 19;
		break;
	case  LD_IY_d_r:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)), getRegVal(bus_pre.r4) );
		nDozeCycles-= 19;
		break;
	case  LD_nn_A:		// checked tchen **********************
		inc_r();
		DozeWrite( bus_pre.nn1, (unsigned char)(Doze.af >> 8) );
		nDozeCycles-= 13;
		break;
	case  LD_nn_dd:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegPairVal_dd(bus_pre.dd2);
		DozeWrite( bus_pre.nn1, (unsigned char)(tempreg & 0x00ff) );
		DozeWrite( (unsigned short)(bus_pre.nn1+1), (unsigned char)(tempreg >> 8) );
		nDozeCycles-= 20;
		break;		
	case  LD_nn_HL:		// checked tchen **********************
		inc_r();
		DozeWrite( bus_pre.nn1, (unsigned char)(Doze.hl & 0x00ff) );
		DozeWrite( (unsigned short)(bus_pre.nn1+1), (unsigned char)(Doze.hl >> 8) );
		nDozeCycles-= 16;
		break;
	case  LD_nn_IX:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( bus_pre.nn2, (unsigned char)(Doze.ix & 0x00ff) );
		DozeWrite( (unsigned short)(bus_pre.nn2+1), (unsigned char)(Doze.ix >> 8) );
		nDozeCycles-= 20;
		break;
	case  LD_nn_IY:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( bus_pre.nn2, (unsigned char)(Doze.iy & 0x00ff) );
		DozeWrite( (unsigned short)(bus_pre.nn2+1), (unsigned char)(Doze.iy >> 8) );
		nDozeCycles-= 20;
		break;
	case  LD_A_BC:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)DozeRead(Doze.bc) << 8) + (Doze.af & 0x00ff) );
		nDozeCycles-= 7;
		break;
	case  LD_A_DE:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)DozeRead(Doze.de) << 8) + (Doze.af & 0x00ff) );
		nDozeCycles-= 7;
		break;
	case  LD_A_nn:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)DozeRead(bus_pre.nn1) << 8) + (Doze.af & 0x00ff) );
		nDozeCycles-= 13;
		break;		
	case  LD_A_I:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( (Doze.ir & 0xff00) + (Doze.af & 0x00ff) );
		flag.S = ( (Doze.af>>15) != 0 ) ? 1 : 0;
		flag.Z = ( (Doze.af>>8) == 0 ) ? 1 : 0;
		flag.H = 0;
		flag.PV = ( (Doze.iff&0x0100) == 0x0100 ) ? 1 : 0;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 9;		
		break;
	case  LD_A_R:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((Doze.ir&0x01)<<15) + ((Doze.ir&0xfe)<<7) 
			+ (Doze.af & 0x00ff) );
		flag.S = ( (Doze.af>>15) != 0 ) ? 1 : 0;
		flag.Z = ( (Doze.af>>8) == 0 ) ? 1 : 0;
		flag.H = 0;								// reset H flag
		flag.PV = ( (Doze.iff&0x0100) == 0x0100 ) ? 1 : 0;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 9;
		break;
	case  LD_dd_nn:		// checked tchen **********************
		inc_r();  inc_r();
		setRegPairVal_dd( bus_pre.dd2, (unsigned short)( (int)DozeRead(bus_pre.nn2) 
			+ ((int)DozeRead((unsigned short)(bus_pre.nn2+1)) << 8) ) );
		nDozeCycles-= 20;
		break;
	case  LD_dd_nn2:		// checked tchen **********************
		inc_r();
		setRegPairVal_dd( bus_pre.dd1, bus_pre.nn1 );
		nDozeCycles-= 10;
		break;
	case  LD_HL_nn:		// checked tchen **********************
		inc_r();
		Doze.hl = (unsigned short)( (int)DozeRead(bus_pre.nn1) + 
			( (int)DozeRead((unsigned short)(bus_pre.nn1+1)) << 8 ) );
		nDozeCycles-= 16;
		break;
	case  LD_I_A:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ir = (unsigned short)( (Doze.af & 0xff00) + (Doze.ir & 0x00ff) );
		nDozeCycles-= 9;
		break;
	case  LD_IX_nn:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ix = (unsigned short)( (int)DozeRead(bus_pre.nn2) + 
			( (int)DozeRead((unsigned short)(bus_pre.nn2+1)) << 8) );
		nDozeCycles-= 20;
		break;
	case  LD_IX_nn2:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ix = bus_pre.nn2;
		nDozeCycles-= 14;
		break;		
	case  LD_IY_nn:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.iy = (unsigned short)( (int)DozeRead(bus_pre.nn2) + 
			( (int)DozeRead((unsigned short)(bus_pre.nn2+1)) << 8) );
		nDozeCycles-= 20;
		break;
	case  LD_IY_nn2:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.iy = bus_pre.nn2;
		nDozeCycles-= 14;
		break;
	case  LD_r_HL:		// checked tchen **********************
		inc_r();
		setRegVal(bus_pre.r1, DozeRead(Doze.hl));
		nDozeCycles-= 7;
		break;
	case  LD_r_IX_d:		// checked tchen **********************
		inc_r();  inc_r();
		setRegVal( bus_pre.r3, DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))) );
		nDozeCycles-= 19;
		break;
	case  LD_r_IY_d:		// checked tchen **********************
		inc_r();  inc_r();
		setRegVal( bus_pre.r3, DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))) );
		nDozeCycles-= 19;
		break;
	case  LD_R_A:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ir = (unsigned short)( ((Doze.af&0x7f)>>7) + ((Doze.af&0x80)>>15) 
			+ (Doze.ir & 0xff00) );
		nDozeCycles-= 9;
		break;
	case  LD_r_r:		// checked tchen **********************
		inc_r();
		setRegVal(bus_pre.r1, getRegVal(bus_pre.r2));
		nDozeCycles-= 4;
		break;		
	case  LD_r_n:		// checked tchen **********************
		inc_r();
		setRegVal(bus_pre.r1, bus_pre.n2);
		nDozeCycles-= 7;
		break;
	case  LD_SP_HL:		// checked tchen **********************
		inc_r();
		Doze.sp = Doze.hl;
		nDozeCycles-= 6;
		break;
	case  LD_SP_IX:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.sp = Doze.ix;
		nDozeCycles-= 10;
		break;
	case  LD_SP_IY:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.sp = Doze.iy;
		nDozeCycles-= 10;
		break;
	case  LDD:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( Doze.de--, DozeRead(Doze.hl--) );
		Doze.bc--;
		flag.H = 0;
		flag.PV = (Doze.bc != 0x0000)? 1:0;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  LDDR:		// checked tchen **********************
		inc_r();  inc_r();
		// new version by tchen 11/18/2002
		DozeWrite( Doze.de--, DozeRead(Doze.hl--) );
		Doze.bc--;
		flag.H = 0;
		flag.N = 0;
		if ( Doze.bc == 0 ) 
		{
			flag.PV = 0;
			nDozeCycles-= 16;
		}
		else
		{
			flag.PV = 1;
			nDozeCycles-= 21;
			Doze.pc-= 2;
			inc_r();
		}
		change_flag();
		break;
	case  LDI:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( Doze.de++, DozeRead(Doze.hl++) );
		Doze.bc--;
		flag.H = 0;
		flag.PV = (Doze.bc != 0x0000)? 1:0;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  LDIR:		// checked tchen **********************
		inc_r();  inc_r();
		// new version by tchen 11/18/2002
		DozeWrite( Doze.de++, DozeRead(Doze.hl++) );
		Doze.bc--;
		flag.H = 0;
		flag.N = 0;
		if ( Doze.bc == 0 ) 
		{
			flag.PV = 0;
			nDozeCycles-= 16;
		}
		else
		{
			flag.PV = 1;
			nDozeCycles-= 21;
			Doze.pc-= 2;
			inc_r();
		}
		change_flag();
		break;
	case  NEG:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8(0, (unsigned char)(Doze.af>>8), 0) << 8) 
			+ (Doze.af & 0x00ff) );		// flag.C?
		change_flag();
		nDozeCycles-= 8;
		break;
	case OR_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_or((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;		
	case OR_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_or((unsigned char)(Doze.af>>8), 
			bus_pre.n2) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case OR_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_or((unsigned char)(Doze.af>>8), 
			DozeRead(Doze.hl)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 7;
		break;
	case OR_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_or((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case OR_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_or((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  OTDR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl);
		Doze.hl--;
		DozeOut(Doze.bc, tempreg2);
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		if ( !flag.Z )		// B != 0, repeat
		{
			inc_r();
			Doze.pc -= 2;
			nDozeCycles-= 21;
		}
		else				// B == 0, stop
		{
			flag.PV = 1;
			change_flag();
			nDozeCycles-= 16;
		}
		break;
	case  OTIR:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl);
		Doze.hl++;
		DozeOut(Doze.bc, tempreg2);
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		if ( !flag.Z )		// B != 0, repeat
		{
			inc_r();
			Doze.pc -= 2;
			nDozeCycles-= 21;
		}
		else				// B == 0, stop
		{
			flag.PV = 1;
			change_flag();
			nDozeCycles-= 16;
		}
		break;
	case  OUT_C_r:		// checked tchen **********************
		inc_r();  inc_r();
		DozeOut( Doze.bc, getRegVal(bus_pre.r3) );
		nDozeCycles-= 12;
		break;
	case  OUT_n_A:		// checked tchen **********************
		inc_r();
		DozeOut( (unsigned short)((Doze.af & 0xff00) + bus_pre.n2), 
			(unsigned char)(Doze.af >> 8) );
		nDozeCycles-= 11;
		break;
	case  OUTD:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl);
		Doze.hl--;
		DozeOut(Doze.bc, tempreg2);
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  OUTI:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg2 = DozeRead(Doze.hl);
		Doze.hl++;
		DozeOut(Doze.bc, tempreg2);
		Doze.bc = (unsigned short)(Doze.bc - 0x0100);
		flag.S = ( (Doze.bc&0x8000)!=0 ) ? 1 : 0;
		flag.Z = ( (Doze.bc&0xFF00)==0 ) ? 1 : 0;
		flag.N = ( (tempreg2&0x0080)!=0 ) ? 1 : 0;
		tempreg = (unsigned short)( Doze.bc&0x00ff );
		tempreg++;
		tempreg = (unsigned short)(tempreg + tempreg2);
		flag.C = flag.H = ( (tempreg&0x0100)!=0 ) ? 1 : 0;
		change_flag();
		nDozeCycles-= 16;
		break;
	case  POP_IX:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.ix = (unsigned short)DozeRead(Doze.sp++);
		Doze.ix = (unsigned short)( ((int)DozeRead(Doze.sp++) << 8) + (Doze.ix & 0x00ff) );
		nDozeCycles-= 14;
		break;
	case  POP_IY:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.iy = (unsigned short)DozeRead(Doze.sp++);
		Doze.iy = (unsigned short)( ((int)DozeRead(Doze.sp++) << 8) + (Doze.iy & 0x00ff) );
		nDozeCycles-= 14;
		break;
	case  POP_qq:		// checked tchen **********************
		inc_r();
		tempreg = DozeRead(Doze.sp++);
		tempreg = (unsigned short)( ((int)DozeRead(Doze.sp++) << 8) + (tempreg & 0x00ff) );
		setRegPairVal_qq( bus_pre.qq1, tempreg );
		nDozeCycles-= 10;
		break;
	case  PUSH_IX:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( --Doze.sp, (unsigned char)(Doze.ix >> 8) );
		DozeWrite( --Doze.sp, (unsigned char)(Doze.ix & 0x00ff) );
		nDozeCycles-= 15;
		break;
	case  PUSH_IY:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( --Doze.sp, (unsigned char)(Doze.iy >> 8) );
		DozeWrite( --Doze.sp, (unsigned char)(Doze.iy & 0x00ff) );
		nDozeCycles-= 15;
		break;
	case  PUSH_qq:		// checked tchen **********************
		inc_r();
		tempreg = getRegPairVal_qq(bus_pre.qq1);
		DozeWrite( --Doze.sp, (unsigned char)(tempreg >> 8) );
		DozeWrite( --Doze.sp, (unsigned char)(tempreg & 0x00ff) );
		nDozeCycles-= 11;
		break;
	case  RES_b_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		setRegVal( bus_pre.r4, resSpecBit(getRegVal(bus_pre.r4), bus_pre.r3) );
		nDozeCycles-= 8;
		break;
	case  RES_b_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( Doze.hl, resSpecBit(DozeRead(Doze.hl), bus_pre.r3) );
		nDozeCycles-= 15;
		break;
	case  RES_b_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)),
			resSpecBit(DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), bus_pre.b4) );
		nDozeCycles-= 23;
		break;
	case  RES_b_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)),
			resSpecBit(DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), bus_pre.b4) );
		nDozeCycles-= 23;
		break;
	case  RET:		// checked tchen **********************
		inc_r();
		Doze.pc = (unsigned short)DozeRead(Doze.sp++);
		Doze.pc = (unsigned short)((((int)DozeRead(Doze.sp++)) << 8) + (Doze.pc & 0x00ff) );
		nDozeCycles-= 10;
		break;
	case  RET_cc:		// checked tchen **********************
		inc_r();
		if( condition_check(bus_pre.r1) )
		{
			Doze.pc = (unsigned short)DozeRead(Doze.sp++);
			Doze.pc = (unsigned short)((((int)DozeRead(Doze.sp++)) << 8) + (Doze.pc & 0x00ff) );
			nDozeCycles-= 11;
		}
		else nDozeCycles-= 5;
		break;
	case  RETI:
		// no use  ???
		nDozeCycles-= 14;
		break;
	case  RETN:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.pc = (unsigned short)DozeRead(Doze.sp++);
		Doze.pc = (unsigned short)((((int)DozeRead(Doze.sp++)) << 8) + (Doze.pc & 0x00ff) );
		Doze.iff = (unsigned short)(((Doze.iff>>8)&0x00ff) + (Doze.iff&0xff00));
		nDozeCycles-= 14;
		break;		
	case  RL_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  RL_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  RL_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RL_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RLA:		// checked tchen **********************
		inc_r();
		tempreg2 = (unsigned char)(((Doze.af & 0x8000) != 0) ? 1 : 0);
		Doze.af = (unsigned short)( ((Doze.af << 1) & 0xfe00) 
			+ ((flag.C)?0x0100:0x0000) + (Doze.af & 0x00ff) );
		flag.C = tempreg2;
		flag.N = 0;
		flag.H = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  RLC_HL:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  RLC_IX_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)) );
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RLC_IY_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)) );
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RLC_r:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)( ((tempreg << 1) & 0x00fe) + (flag.C?1:0) );
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;		
	case  RLCA:		// checked tchen **********************
		inc_r();
		flag.C = ((Doze.af & 0x8000) != 0) ? 1 : 0;
		Doze.af = (unsigned short)( ((Doze.af << 1) & 0xfe00) 
			+ ((flag.C)?0x0100:0x0000) + (Doze.af & 0x00ff) );
		flag.N = 0;
		flag.H = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case RLD:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);	// (HL)
		DozeWrite( Doze.hl, (unsigned char)(((tempreg&0x0f)<<4)+((Doze.af&0x0f00)>>8)) );
		tempreg2 = (unsigned char)( ((tempreg&0xf0)>>4) + ((Doze.af&0xf000)>>8) );	// A
		Doze.af = (unsigned short)( ((int)tempreg2<<8) + (Doze.af&0x00ff) );
		flag.S = ( (tempreg2 & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg2 & 0x00ff) == 0 ) ? 1 : 0;
		flag.H = 0;
		flag.N = 0;
		flag.PV = parity_check(tempreg2);
		change_flag();
		nDozeCycles-= 18;
		break;
	case  RR_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);		
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  RR_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite(Doze.hl,(unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  RR_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RR_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		tempreg2 = (unsigned char)(((tempreg & 0x0080) != 0) ? 1 : 0 );
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.C = tempreg2;
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RRA:		// checked tchen **********************
		inc_r();
		tempreg2 = (unsigned char)(((Doze.af & 0x0100) != 0) ? 1 : 0);
		Doze.af = (unsigned short)( ((Doze.af >> 1) & 0x7f00) 
			+ ((flag.C)?0x8000:0x0000) + (Doze.af & 0x00ff));
		flag.C = tempreg2;
		flag.N = 0;
		flag.H = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  RRC_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  RRC_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  RRC_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RRC_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (flag.C?0x0080:0x0000));
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  RRCA:		// checked tchen **********************
		inc_r();
		flag.C = ((Doze.af & 0x0100) != 0) ? 1 : 0;
		Doze.af = (unsigned short)( ((Doze.af >> 1) & 0x7f00) 
			+ ((flag.C)?0x8000:0x0000) + (Doze.af & 0x00ff) );
		flag.N = 0;
		flag.H = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  RRD:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);	// (HL)
		DozeWrite( Doze.hl, (unsigned char)(((tempreg&0xf0)>>4)+((Doze.af&0x0f00)>>4)) );
		tempreg2 = (unsigned char)( (tempreg&0x0f) + ((Doze.af&0xf000)>>8) );	// A
		Doze.af = (unsigned short)( ((int)tempreg2<<8) + (Doze.af&0x00ff) );
		flag.S = ( (tempreg2 & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg2 & 0x00ff) == 0 ) ? 1 : 0;
		flag.H = 0;
		flag.N = 0;
		flag.PV = parity_check(tempreg2);
		change_flag();
		nDozeCycles-= 18;
		break;
	case  RST_p:		// checked tchen **********************
		inc_r();
		DozeWrite( --Doze.sp, (unsigned char)(Doze.pc >> 8) );
		DozeWrite( --Doze.sp, (unsigned char)(Doze.pc & 0x00ff) );
		switch( bus_pre.r1 )
		{
		case 0x00: 
			Doze.pc = 0x0000;
			break;
		case 0x01:
			Doze.pc = 0x0008;
			break;
		case 0x02: 
			Doze.pc = 0x0010;
			break;
		case 0x03:
			Doze.pc = 0x0018;
			break;
		case 0x04: 
			Doze.pc = 0x0020;
			break;
		case 0x05:
			Doze.pc = 0x0028;
			break;
		case 0x06: 
			Doze.pc = 0x0030;
			break;
		case 0x07:
			Doze.pc = 0x0038;
			break;
		}
		nDozeCycles-= 11;
		break;
	case SBC_A_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2), flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;
	case SBC_A_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8((unsigned char)(Doze.af>>8), 
			(unsigned char)bus_pre.n2, flag.C) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case SBC_A_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8((unsigned char)(Doze.af>>8),
			DozeRead(Doze.hl), flag.C) << 8) + (Doze.af & 0x00ff));
		nDozeCycles-= 7;
		break;
	case SBC_A_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), flag.C) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case SBC_A_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), flag.C) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  SBC_HL_ss:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.hl = Arith_sub16( Doze.hl, getRegPairVal_dd(bus_pre.dd2), flag.C );
		change_flag();
		nDozeCycles-= 15;
		break;
	case  SCF:		// checked tchen **********************
		inc_r();
		flag.C = 1;
		flag.H = 0;
		flag.N = 0;
		change_flag();
		nDozeCycles-= 4;
		break;
	case  SET_b_HL:		// checked tchen **********************
		inc_r();  inc_r();
		DozeWrite( Doze.hl, setSpecBit(DozeRead(Doze.hl), bus_pre.r3) );
		nDozeCycles-= 15;
		break;
	case  SET_b_IX_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.ix + sign_extend(bus_pre.d)),
			setSpecBit(DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), bus_pre.b4) );
		nDozeCycles-= 23;
		break;
	case  SET_b_IY_d:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		DozeWrite( (unsigned short)(Doze.iy + sign_extend(bus_pre.d)),
			setSpecBit(DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), bus_pre.b4) );
		nDozeCycles-= 23;
		break;
	case  SET_b_r:		// checked tchen **********************
		inc_r();  inc_r();
		setRegVal( bus_pre.r4, setSpecBit(getRegVal(bus_pre.r4), bus_pre.r3) );
		nDozeCycles-= 8;
		break;
	case  SLA_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg << 1) & 0x00fe);
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  SLA_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg << 1) & 0x00fe);
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  SLA_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg << 1) & 0x00fe);
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SLA_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0080) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg << 1) & 0x00fe);
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SRA_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (tempreg & 0x0080));
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  SRA_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (tempreg & 0x0080));
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  SRA_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (tempreg & 0x0080));
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SRA_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)(((tempreg >> 1) & 0x007f) + (tempreg & 0x0080));
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SRL_m_1:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = getRegVal(bus_pre.r4);
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg >> 1) & 0x007f);
		setRegVal(bus_pre.r4, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 8;
		break;
	case  SRL_m_2:		// checked tchen **********************
		inc_r();  inc_r();
		tempreg = DozeRead(Doze.hl);
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg >> 1) & 0x007f);
		DozeWrite(Doze.hl, (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 15;
		break;
	case  SRL_m_3:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg >> 1) & 0x007f);
		DozeWrite((unsigned short)(Doze.ix + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SRL_m_4:		// checked tchen **********************
		inc_r();  inc_r();  inc_r();
		tempreg = DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)));
		flag.C = ((tempreg & 0x0001) != 0) ? 1 : 0;
		tempreg = (unsigned short)((tempreg >> 1) & 0x007f);
		DozeWrite((unsigned short)(Doze.iy + sign_extend(bus_pre.d)), (unsigned char)tempreg);
		flag.S = ( (tempreg & 0x0080) != 0 ) ? 1 : 0;
		flag.Z = ( (tempreg & 0x00ff) == 0 ) ? 1 : 0;
		flag.N = 0;
		flag.H = 0;
		flag.PV = parity_check((unsigned char)tempreg);
		change_flag();
		nDozeCycles-= 23;
		break;
	case  SUB_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( (int)(Arith_sub8((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2), 0) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;
	case  SUB_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( (int)(Arith_sub8((unsigned char)(Doze.af>>8), 
			(unsigned char)bus_pre.n2, 0) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case  SUB_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( (int)(Arith_sub8((unsigned char)(Doze.af>>8),
			DozeRead(Doze.hl), 0) << 8) + (Doze.af & 0x00ff));
		change_flag();
		nDozeCycles-= 7;
		break;
	case  SUB_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( (int)(Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d))), 0) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case  SUB_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( (int)(Arith_sub8((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d))), 0) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case XOR_s_1:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_xor((unsigned char)(Doze.af>>8), 
			getRegVal(bus_pre.r2)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 4;
		break;		
	case XOR_s_2:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_xor((unsigned char)(Doze.af>>8), 
			bus_pre.n2) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 8;	// Z80 manual is 7
		break;
	case XOR_s_3:		// checked tchen **********************
		inc_r();
		Doze.af = (unsigned short)( ((int)Arith_xor((unsigned char)(Doze.af>>8), 
			DozeRead(Doze.hl)) << 8) + (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 7;
		break;
	case XOR_s_4:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_xor((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.ix + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	case XOR_s_5:		// checked tchen **********************
		inc_r();  inc_r();
		Doze.af = (unsigned short)( ((int)Arith_xor((unsigned char)(Doze.af>>8), 
			DozeRead((unsigned short)(Doze.iy + sign_extend(bus_pre.d)))) << 8)
			+ (Doze.af & 0x00ff) );
		change_flag();
		nDozeCycles-= 19;
		break;
	default:
		printf("Unrecognized pre-decoded result!!\n");
		break;
	}

	if (Doze.pc == 0x0306)
		Doze.pc += 0;

	inst_count++;
	if ( (inst_count%10) == 0 ) 
		Doze.pc += 0;

}
