/*==========================================================================================*
|	Z80 Instructions Execution																|
|																							|
|						Writen by			 Tsung-Chi, Lin		(I/O group)					|
| ----------------------------------------------------------------------------------------- |
|	Date:																					|
|	11/01/2002	Original version established.												|
|	11/03/2002	Complete Load Group Instruction												|
|	11/04/2002	Complete Exchange, Block Transfer, Search Group Instruction					|
|	11/04/2002	Complete Arithmetic Group Instruction 										|
|	11/05/2002	Complete ROTATE and SHIFT Group Instruction									|
|	11/05/2002	Complete BIT, RESET, and TEST Group Instruction								|
|	11/05/2002	Complete JUMP Group Instruction												|
|	11/05/2002	Complete CALL and RETURN Group Instruction									|
|	11/06/2002	Complete INPUT and OUTPUT Group Instruction									|
*==========================================================================================*/
#ifndef __Z80_I_RUN_H
#define __Z80_I_RUN_H

unsigned char getRegVal(unsigned char r);	//return the value of specified Register
void setRegVal(unsigned char r, unsigned char v); //store the value to specified Register
unsigned short getRegPairVal_dd(unsigned char dd); //return the value to specified Register
void setRegPairVal_dd(unsigned char dd, unsigned short v); //store the value to specified Register
unsigned short getRegPairVal_qq (unsigned char qq); //return the value to specified Register
void setRegPairVal_qq(unsigned char qq, unsigned short v); //store the value to specified Register
unsigned short getRegPairVal_pp(unsigned char pp); //return the value to specified Register
void setRegPairVal_pp(unsigned char pp, unsigned short v); //store the value to specified Register


unsigned short getRegPairVal_rr (unsigned char rr); //return the value to specified Register
void setRegPairVal_rr (unsigned char rr, unsigned short v); //store the value to specified Register


unsigned char Arith_add8(unsigned char opd1, unsigned char opd2, bool carry);
unsigned char Arith_sub8(unsigned char opd1, unsigned char opd2, bool carry);
void compare(unsigned char opd1, unsigned char opd2);
unsigned short Arith_add16(unsigned short opd1, unsigned short opd2, bool carry);
unsigned short Arith_sub16(unsigned short opd1, unsigned short opd2, bool carry);
unsigned char Arith_and(unsigned char opd1, unsigned char opd2);
unsigned char Arith_or(unsigned char opd1, unsigned char opd2);
unsigned char Arith_xor(unsigned char opd1, unsigned char opd2);
bool parity_check(unsigned char opd);
bool overflow_check(bool sign1, bool sign2, bool sign_result);
bool condition_check(unsigned char cond);

void getSpecBit(unsigned char opd, unsigned char bit_num);		// use for BIT Group
unsigned char setSpecBit(unsigned char opd, unsigned char bit_num);	// use for SET Group
unsigned char resSpecBit(unsigned char opd, unsigned char bit_num);	// use for SET Group

unsigned short sign_extend(unsigned char a);
// int sign_extend(unsigned short a);

void INSTR_RUN(unsigned char z80_ID);



#endif